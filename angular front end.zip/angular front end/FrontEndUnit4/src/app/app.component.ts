import { Component } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

 
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']

  
})
export class AppComponent {
  title = 'my-app';
  constructor(private http: HttpClient) {}

  getAll() {

    this.http.get('http://localhost:3000/api/getAll').subscribe(data => {

    })
  }
  getOne() {
    this.http.get('http://localhost:3000/api/getOne/63faa4abbf2400af7996c2a1').subscribe(data => {
 
    })
   
  }
  getWeight() {
    this.http.get('http://localhost:3000/api/getWeight').subscribe(data => {
 
    })
  }
  getCollege() {
    this.http.get('http://localhost:3000/api/getCollege').subscribe(data => {

    })
  }
  getWins() {
    this.http.get('http://localhost:3000/api/getWins').subscribe(data => {
      
    })  }
    deleteUser() {
      console.log('here in app.components')
    this.http.delete('http://localhost:3000/api/delete').subscribe(data => {
    console.log('here in app.components')
    })  }
}